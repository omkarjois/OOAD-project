package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Home extends JFrame {
    public Home() {
        setTitle("Home Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(850, 1000);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1));

        JButton accountsButton = new JButton("Accounts Overview");
        accountsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Code to open Accounts Overview page
                JOptionPane.showMessageDialog(null, "Opening Accounts Overview page");
            }
        });

        JButton loansButton = new JButton("Loans");
        loansButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Code to open Loans page
                JOptionPane.showMessageDialog(null, "Opening Loans page");
            }
        });

        JButton paymentButton = new JButton("Payment");
        paymentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Code to open Payment page
                new Payment();
                setVisible(false);
            }
        });

        JButton profileButton = new JButton("Profile");
        profileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Code to open Profile page
                JOptionPane.showMessageDialog(null, "Opening Profile page");
            }
        });

        panel.add(accountsButton);
        panel.add(loansButton);
        panel.add(paymentButton);
        panel.add(profileButton);

        add(panel);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Home();
            }
        });
    }
}

